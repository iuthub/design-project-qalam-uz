
This is Project made by Otabek Nazrullaev, Sardorbek Abdupattoev, Mirpulatjon Shukurov



### License

This project and the underlying Laravel framework are open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)