<h3>You Have a New Contact Via the Contact Form</h3>

<div>
	{{ $bodyMessage }}
</div>

<p>Sent via {{ $email }}</p>