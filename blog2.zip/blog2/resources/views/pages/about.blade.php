@extends('main')

@section('title', '| About')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <h1>About Us</h1>
                <p>This is the free blog! Feel free to write anything in comment:)</p>
            </div>
        </div>

@endsection
