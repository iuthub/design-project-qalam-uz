<?php $__env->startSection('title', '| Homepage'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="jumbotron">
                  <h1>Welcome to MSO Blog!</h1>
                  <p class="lead">Thank you so much for visiting. This is our website built with Laravel<br>by Mirpulatjon, Sardorbek and Otabek(MSO).</p>
                </div>
            </div>
        </div> <?php /* Qolgani main o'zida, bo'ldi*/ ?>

        <div class="row">
            <div class="col-md-8">
                
                <?php foreach($posts as $post): ?>

                    <div class="post">
                        <h3><?php echo e($post->title); ?></h3>
                        <p><?php echo e(substr(strip_tags($post->body), 0, 300)); ?><?php echo e(strlen(strip_tags($post->body)) > 300 ? "..." : ""); ?></p>
                        <a href="<?php echo e(url('blog/'.$post->slug)); ?>" class="btn btn-primary">Read More</a>
                    </div>

                    <hr>

                <?php endforeach; ?>

            </div>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>