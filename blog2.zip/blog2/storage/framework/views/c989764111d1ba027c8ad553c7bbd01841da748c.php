<?php $__env->startSection('title', '| About'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <h1>About Us</h1>
                <p>This is the free blog! Feel free to write anything in comment:)</p>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>